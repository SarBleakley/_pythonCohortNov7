from django.shortcuts import render, redirect, HttpResponse
import datetime
import pytz

def index(request):
	date = datetime.datetime.now(pytz.timezone('America/New_York')).strftime("(%Y/%m/%d %I:%M:%S %p)")
	context = {
	"somekey":date
	}
	return render(request, 'timedisplay/index.html', context)
